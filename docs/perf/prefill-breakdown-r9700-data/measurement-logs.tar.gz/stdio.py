import json, os, struct, subprocess, sys, time
root='/home/homelab1/coding-local/shelf/.worktrees/prefill-breakdown'
model='/home/homelab1/datapool/rocm-exl3-rdna2/models/qwen38-27b-exl3-4bpw-mul24'
args=[root+'/build-gfx1201/shelf-compute','--model-dir',model,'--serve-stdio','--max-seq-len','4096','--max-concurrent-requests','1','--prefix-cache','0','--kv-cache-dtype','bf16','--temperature','0']
if sys.argv[1]=='draft': args += ['--dflash2-model-dir','/home/homelab1/datapool/ai_models/safetensors/Qwen3.8-27B-DFlash2','--dflash2-drafts','7']
b=open('/tmp/shelf-prefill-32768.psktok','rb').read(); ids=struct.unpack_from('<2048i',b,20)
p=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1)
def send(x):p.stdin.write(json.dumps(x)+'\n');p.stdin.flush()
def recv():
 s=p.stdout.readline()
 if not s: raise RuntimeError('process ended '+str(p.poll()))
 return json.loads(s)
try:
 send({'op':'ping'})
 while recv().get('event')!='pong':pass
 for i in range(6):
  start=time.monotonic();first=None;send({'op':'generate','request_id':i+1,'input_ids':ids,'max_new_tokens':1,'temperature':0.0})
  while True:
   e=recv()
   if e.get('request_id')!=i+1:continue
   if e.get('event')=='token' and first is None:first=time.monotonic()
   if e.get('event')=='error':raise RuntimeError(str(e))
   if e.get('event')=='done':
    print(json.dumps({'run':i,'ttft_ms':1000*(first-start) if first else None,'done_ms':1000*(time.monotonic()-start),'generated_ids':e.get('generated_ids')}),flush=True);break
finally:
 if p.poll() is None:
  send({'op':'shutdown'});p.stdin.close()
  try:p.wait(timeout=30)
  except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10)
