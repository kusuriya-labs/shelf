import csv,collections,statistics,json
p='/tmp/prefill-r9700/timing/semantic_timing.csv'; r=sorted(csv.DictReader(open(p)),key=lambda x:int(x['seq']));runs=[]
for x in r:
 if x['kernel_id']=='EMBEDDING_LOOKUP':runs.append([])
 runs[-1].append(x)
out=[]
for run in runs:
 agg=collections.defaultdict(float); counts=collections.Counter(); layer=0; residual=0; linear=0; layers=collections.defaultdict(float); parent='';
 for x in run:
  kid=x['kernel_id']; ms=float(x['duration_us'])/1000
  if kid.startswith('EXL3_'):
   agg['stage '+kid]+=ms; counts['stage '+kid]+=1; agg['stage '+parent+' '+kid]+=ms
   continue
  agg['all '+kid]+=ms; counts['all '+kid]+=1
  if kid=='EMBEDDING_LOOKUP': continue
  if layer>=64:
   agg['tail '+kid]+=ms; counts['tail '+kid]+=1; continue
  typ='attn' if layer%4==3 else 'gdn'
  layers[layer]+=ms
  if kid=='LINEAR_EXL3_INT8':
   names=(['q','k','v','o','gate','up','down'] if typ=='attn' else ['qkv','z','o','gate','up','down']); parent=typ+' '+names[linear]; linear+=1; agg[parent]+=ms; counts[parent]+=1
  if kid=='RESIDUAL_ADD':
   residual+=1
   if residual==2:
    assert linear==(7 if typ=='attn' else 6),(layer,linear)
    layer+=1; residual=0; linear=0
 assert layer==64
 agg['gdn layers']=sum(v for k,v in layers.items() if k%4!=3);agg['attn layers']=sum(v for k,v in layers.items() if k%4==3)
 out.append((agg,counts,layers))
keys=sorted(out[0][0]);
for k in keys:
 vals=[x[0][k] for x in out]; print(f'{k:48} {statistics.median(vals):9.3f} ms {out[0][1][k]:4} calls range {min(vals):.3f}..{max(vals):.3f}')
